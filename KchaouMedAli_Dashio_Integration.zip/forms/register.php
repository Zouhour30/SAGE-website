<?php

include('../config.php');

$connection = new mysqli($servername, $username, $password, $dbname);
$fname = $_POST['nom_p'];
$lname = $_POST['pernom_p'];
$address = $_POST['adresse_p'];
$dob = $_POST['date_de_naissance'];
$email = $_POST['email_p'];
$password = $_POST['mot_de_passe'];

$sql = "INSERT INTO personnes (nom_p, pernom_p, adresse_p, date_de_naissance, email_p, mot_de_passe)
VALUES ('$fname', '$lname', '$address', '$dob', '$email', '$password')";

if ($connection->query($sql) === TRUE) {
  echo "Thank you for your sign up !";
} else {
  echo "Error: " . $sql . "<br>" . $connection->error;
}

$connection->close();


?>